House of Coders, Internship Project of Ranula

# Download Git Repository and -run with Android Studio
