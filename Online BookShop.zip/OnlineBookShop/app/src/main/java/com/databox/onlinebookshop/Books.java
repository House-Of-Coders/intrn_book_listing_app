package com.databox.onlinebookshop;

public class Books {
    String bookImage;
    String bookName;
    String bookCategory;
    String bookISBN;
    String bookPrice;

    public Books(String bokImage , String bookName, String bookCategory, String bookISBN, String bookPrice) {
        this.bookImage = bokImage;
        this.bookName = bookName;
        this.bookCategory = bookCategory;
        this.bookISBN = bookISBN;
        this.bookPrice = bookPrice;
    }

    public String getBookImage() {
        return bookImage;
    }

    public void setBookImage(String bookImage) {
        this.bookImage = bookImage;
    }

    public String getBookName() {
        return bookName;
    }

    public void setBookName(String bookName) {
        this.bookName = bookName;
    }

    public String getBookCategory() {
        return bookCategory;
    }

    public void setBookCategory(String bookCategory) {
        this.bookCategory = bookCategory;
    }

    public String getBookISBN() {
        return bookISBN;
    }

    public void setBookISBN(String bookISBN) {
        this.bookISBN = bookISBN;
    }

    public String getBookPrice() {
        return bookPrice;
    }

    public void setBookPrice(String bookPrice) {
        this.bookPrice = bookPrice;
    }
}


