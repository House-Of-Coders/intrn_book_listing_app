package com.databox.onlinebookshop;

public class uploadImg {

    public String imageName;
    public String  imgUrl;
    public uploadImg(){}

    public uploadImg(String imageName, String imgUrl) {
        this.imageName = imageName;
        this.imgUrl = imgUrl;
    }

    public String getImageName() {
        return imageName;
    }

    public void setImageName(String imageName) {
        this.imageName = imageName;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }
}
